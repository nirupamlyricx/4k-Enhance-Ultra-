import express from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Database from "better-sqlite3";

const app = express();
const PORT = Number(process.env.PORT || 8787);
const JWT_SECRET = process.env.JWT_SECRET;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || "http://localhost:8080";
if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET to a random secret of at least 32 characters.");
  process.exit(1);
}
app.use(helmet());
app.use(cors({ origin: FRONTEND_ORIGIN, methods: ["GET", "POST", "PUT"], allowedHeaders: ["Content-Type", "Authorization"] }));
app.use(express.json({ limit: "2mb" }));
app.use("/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 20 }));
app.use("/register", rateLimit({ windowMs: 60 * 60 * 1000, limit: 10 }));

const db = new Database(process.env.DB_PATH || "./4k-enhance.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sync_data (user_id INTEGER PRIMARY KEY, edits_json TEXT NOT NULL DEFAULT '[]', updated_at TEXT NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id));
`);
const findUser = db.prepare("SELECT * FROM users WHERE email = ?");
const addUser = db.prepare("INSERT INTO users(email,password_hash,created_at) VALUES(?,?,?)");
const findSync = db.prepare("SELECT edits_json FROM sync_data WHERE user_id = ?");
const saveSync = db.prepare(`INSERT INTO sync_data(user_id,edits_json,updated_at) VALUES(?,?,?)
 ON CONFLICT(user_id) DO UPDATE SET edits_json=excluded.edits_json, updated_at=excluded.updated_at`);

function issueToken(user) {
  return jwt.sign({ sub: String(user.id), email: user.email }, JWT_SECRET, { expiresIn: "7d", issuer: "4k-enhance-ultra" });
}
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    req.user = jwt.verify(token, JWT_SECRET, { issuer: "4k-enhance-ultra" });
    next();
  } catch {
    res.status(401).json({ message: "Please sign in again." });
  }
}
app.get("/health", (_req, res) => res.json({ ok: true }));
app.post("/register", async (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: "Enter a valid email." });
  if (password.length < 10) return res.status(400).json({ message: "Password must be at least 10 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = addUser.run(email, hash, new Date().toISOString());
    const user = { id: result.lastInsertRowid, email };
    res.status(201).json({ token: issueToken(user), message: "Account created and signed in." });
  } catch (e) {
    if (String(e).includes("UNIQUE")) return res.status(409).json({ message: "An account with this email already exists." });
    console.error(e); res.status(500).json({ message: "Could not create account." });
  }
});
app.post("/login", async (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  const user = findUser.get(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ message: "Invalid email or password." });
  res.json({ token: issueToken(user), email: user.email });
});
app.put("/sync", auth, (req, res) => {
  const edits = req.body?.edits;
  if (!Array.isArray(edits) || edits.length > 12) return res.status(400).json({ message: "edits must be an array with at most 12 entries." });
  const safeEdits = edits.map(e => ({
    id: String(e.id || "").slice(0, 100),
    createdAt: String(e.createdAt || "").slice(0, 40),
    width: Number(e.width) || 0,
    height: Number(e.height) || 0,
    preset: String(e.preset || "").slice(0, 80),
    label: String(e.label || "").slice(0, 120),
    preview: typeof e.preview === "string" && e.preview.length < 700000 ? e.preview : ""
  }));
  saveSync.run(Number(req.user.sub), JSON.stringify(safeEdits), new Date().toISOString());
  res.json({ ok: true, count: safeEdits.length });
});
app.get("/sync", auth, (req, res) => {
  const row = findSync.get(Number(req.user.sub));
  let edits = [];
  try { edits = JSON.parse(row?.edits_json || "[]"); } catch {}
  res.json({ edits });
});
app.listen(PORT, () => console.log(`4K Enhance API listening on port ${PORT}`));
