4K Enhance Ultra — PWA package

Files:
- index.html: updated app
- manifest.json: PWA manifest
- service-worker.js: app-shell cache/offline fallback
- icon.svg: app icon

Install:
1. Upload all files to the same folder on an HTTPS static host (or run on localhost).
2. Open index.html in a supported browser such as Chrome/Edge.
3. Use the app's Install App button or browser menu → Install app / Add to Home Screen.

Important:
- A standalone HTML opened as file:// cannot register a service worker, so use the complete package on HTTPS for PWA installability.
- AI background removal needs an API endpoint that accepts multipart field "image" and returns an image/* response or JSON containing dataUrl/imageUrl/url.
- Login/cloud sync needs your own secure backend: POST /login returning token/accessToken; PUT /sync accepting Bearer auth and JSON {edits:[...]}.
- No API secret or payment credential is included. Do not put private API keys in client-side HTML.

A sample Node.js backend is included in backend-example/. Configure and deploy it separately; the HTML cannot host the backend itself.
